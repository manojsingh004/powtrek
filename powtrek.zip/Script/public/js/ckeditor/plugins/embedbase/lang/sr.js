/*
Copyright (c) 2003-2020, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or https://ckeditor.com/legal/ckeditor-oss-license
*/
CKEDITOR.plugins.setLang( 'embedbase', 'sr', {
	pathName: 'медијски објекат',
	title: 'Уградња медија',
	button: 'Зметните уграђене медије',
	unsupportedUrlGiven: 'Дат УРЛ није подржан',
	unsupportedUrl: ' Уграђивање медија не подржава УРЛ  {url}.',
	fetchingFailedGiven: 'Није успело издвајање садржаја за наведени УРЛ .',
	fetchingFailed: 'Није успело издвојити садржај {url}-a.',
	fetchingOne: 'oЕмбед преузимање одговора...',
	fetchingMany: 'oЕмбед преузимање одговора у току, {current} од {max} спремно ...'
} );
